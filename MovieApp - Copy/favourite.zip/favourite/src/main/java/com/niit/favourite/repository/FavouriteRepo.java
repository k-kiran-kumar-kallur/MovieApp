package com.niit.favourite.repository;

import com.niit.favourite.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FavouriteRepo extends MongoRepository<User,String> {
}
